package com.example.list_dan_listview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
