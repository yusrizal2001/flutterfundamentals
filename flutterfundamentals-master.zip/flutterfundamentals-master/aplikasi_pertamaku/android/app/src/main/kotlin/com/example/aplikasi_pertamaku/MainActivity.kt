package com.example.aplikasi_pertamaku

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
