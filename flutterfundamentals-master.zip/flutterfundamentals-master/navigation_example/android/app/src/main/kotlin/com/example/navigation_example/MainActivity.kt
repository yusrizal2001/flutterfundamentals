package com.example.navigation_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
