package com.example.stateless_dan_stateful

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
