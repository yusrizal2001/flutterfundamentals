package com.example.bloc_blocflutterpackage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
