package com.example.bloc_plain

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
