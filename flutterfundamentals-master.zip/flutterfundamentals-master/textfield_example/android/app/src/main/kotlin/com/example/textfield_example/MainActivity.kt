package com.example.textfield_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
