package com.example.row_coloumn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
